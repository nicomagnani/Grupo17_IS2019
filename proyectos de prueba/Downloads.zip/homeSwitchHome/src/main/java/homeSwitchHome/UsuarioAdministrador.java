package homeSwitchHome;

import java.awt.List;

public class UsuarioAdministrador extends Usuario {

	public UsuarioAdministrador() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	private String contraseña;
	
	private Propiedad agregarResidencia() {
		return null;
	} //TODO
	
	private void modificarResidencia() {
	} //TODO
	
	//private List<Reserva> verReservas()
	//{
	//	return null;
//	}
}
