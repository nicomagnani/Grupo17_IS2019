package homeSwitchHome;

import java.awt.Image;

public class Propiedad {
	private String titulo,pais,provincia,localidad,domicilio,descripción;
	private float montoBase;
	private Image[] fotos = new Image[5];
	
	public void reservarSemana(int unaSemana)
	{
		
	}
	
	public void anularReservaSemana(int unaSemana)
	{
		
	}
	
}
