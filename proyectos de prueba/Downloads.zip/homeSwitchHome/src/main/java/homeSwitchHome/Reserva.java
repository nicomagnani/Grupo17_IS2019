package homeSwitchHome;

abstract public class Reserva {
		
	public Reserva() { //crearReserva(), tal vez lo borremos
		super();
	}

	private int semana;
	
	abstract public void borrarReserva();
	
}
